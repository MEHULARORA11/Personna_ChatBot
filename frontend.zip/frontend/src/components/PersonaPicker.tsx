import { motion } from 'framer-motion';
import { Play, Users, Coffee, Terminal } from 'lucide-react';

export interface Persona {
  id: 'hitesh' | 'piyush';
  name: string;
  role: string;
  bio: string;
  youtube: string;
  subscribers: string;
  signatureEmoji: string;
  avatarUrl: string;
}

const PERSONAS: Persona[] = [
  {
    id: 'hitesh',
    name: 'Hitesh Choudhary',
    role: 'Coding Mentor & Chai Lover',
    bio: 'Ex-PW, iNeuron CTO. Builds ChaiCode & Masterji.co. Teaches with intuition-first, conversational Hinglish explanations.',
    youtube: 'Chai aur Code',
    subscribers: '1.8M+ subs',
    signatureEmoji: '☕',
    avatarUrl: '/hitesh.png',
  },
  {
    id: 'piyush',
    name: 'Piyush Garg',
    role: 'System Design & Backend Enthusiast',
    bio: 'Startup engineer and event-driven architecture enthusiast. High-energy livestreaming teacher.',
    youtube: 'Code with Piyush',
    subscribers: '1M+ subs',
    signatureEmoji: '🚀',
    avatarUrl: '/piyush.jpg',
  },
];

interface PersonaPickerProps {
  activePersona: 'hitesh' | 'piyush';
  onPersonaChange: (id: 'hitesh' | 'piyush') => void;
}

export default function PersonaPicker({ activePersona, onPersonaChange }: PersonaPickerProps) {
  return (
    <div className="w-full flex flex-col gap-3">
      {/* Desktop / tablet: vertical card list */}
      <div className="hidden md:flex flex-col gap-3">
        {PERSONAS.map((persona) => {
          const isActive = activePersona === persona.id;
          const isHitesh = persona.id === 'hitesh';
          return (
            <button
              key={persona.id}
              onClick={() => onPersonaChange(persona.id)}
              className={`text-left w-full p-5 rounded-2xl border transition-all duration-200 relative flex flex-col gap-3 cursor-pointer ${
                isActive
                  ? 'bg-bg-surface border-transparent shadow-md'
                  : 'bg-transparent border-border-main hover:border-text-muted/40 hover:bg-bg-surface/50'
              }`}
              style={
                isActive
                  ? { boxShadow: `0 0 0 1.5px ${isHitesh ? 'var(--accent)' : 'var(--engine)'}` }
                  : undefined
              }
              aria-pressed={isActive}
            >
              <div className="flex items-start gap-3.5">
                <div className="relative shrink-0">
                  <div
                    className={`w-12 h-12 rounded-full overflow-hidden border transition-colors ${
                      isActive ? 'border-transparent' : 'border-border-main'
                    }`}
                  >
                    <img
                      src={persona.avatarUrl}
                      alt={persona.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  {isActive && (
                    <span
                      className="absolute -bottom-0.5 -right-0.5 w-4 h-4 rounded-full border-2 flex items-center justify-center text-[8px]"
                      style={{
                        borderColor: 'var(--bg-surface)',
                        backgroundColor: isHitesh ? 'var(--accent)' : 'var(--engine)',
                      }}
                    >
                      {isHitesh ? <Coffee className="w-2.5 h-2.5 text-white" /> : <Terminal className="w-2.5 h-2.5 text-white" />}
                    </span>
                  )}
                </div>
                <div className="min-w-0">
                  <h3 className="text-[15px] font-semibold text-text-primary flex items-center gap-1.5 font-display truncate">
                    {persona.name}
                    <span className="text-base">{persona.signatureEmoji}</span>
                  </h3>
                  <p className="text-xs text-text-muted mt-0.5">{persona.role}</p>
                </div>
              </div>

              <p className="text-[13px] text-text-muted leading-relaxed">{persona.bio}</p>

              <div className="flex items-center gap-4 text-[11px] font-mono text-text-muted pt-3 border-t border-border-main/70">
                <span className="flex items-center gap-1">
                  <Users className="w-3 h-3" />
                  {persona.subscribers}
                </span>
                <span className="flex items-center gap-1">
                  <Play className="w-3 h-3 fill-current" />
                  {persona.youtube}
                </span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Mobile: compact segmented switcher */}
      <div className="md:hidden flex gap-1.5 p-1.5 bg-bg-surface border border-border-main rounded-2xl">
        {PERSONAS.map((persona) => {
          const isActive = activePersona === persona.id;
          return (
            <button
              key={persona.id}
              onClick={() => onPersonaChange(persona.id)}
              className="flex-1 relative py-2.5 rounded-xl cursor-pointer"
              aria-pressed={isActive}
            >
              {isActive && (
                <motion.div
                  layoutId="activeTabIndicator"
                  className="absolute inset-0 rounded-xl bg-bg-base border border-border-main"
                  transition={{ type: 'spring', stiffness: 400, damping: 32 }}
                />
              )}
              <span className="relative z-10 flex items-center justify-center gap-2">
                <span className="w-6 h-6 rounded-full overflow-hidden border border-border-main shrink-0">
                  <img src={persona.avatarUrl} alt={persona.name} className="w-full h-full object-cover" />
                </span>
                <span className={`text-sm font-medium font-display ${isActive ? 'text-text-primary' : 'text-text-muted'}`}>
                  {persona.name.split(' ')[0]}
                </span>
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
